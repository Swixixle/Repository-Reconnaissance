# AI Receipts Forensic Pack Verifier

Version: replit-node-verifier/0.2.0
Commit: 774b76fa2b21

## What This Does

Verifies AI Receipts forensic packs offline without any database access.
It replays the SHA-256 hash chain deterministically and verifies Ed25519
checkpoint signatures.

## Quick Start

### Verify with included public key (recommended)

```bash
node verify.js forensic_pack.json --public-key checkpoint_public.pem
```

### Verify hash chain only (no signature check)

```bash
node verify.js forensic_pack.json
```

## Requirements

- Node.js 18+ (for crypto module with Ed25519 support)
- No other dependencies required

## What Gets Verified

1. **Pack integrity** - SHA-256 of the entire pack matches packHash
2. **Sequence continuity** - No gaps in event sequence numbers
3. **Hash chain** - Each event hash matches its canonical payload
4. **Chain linkage** - Each event prevHash matches previous event hash
5. **Checkpoint anchoring** - Checkpoint hashes match corresponding event hashes
6. **Checkpoint chain** - Checkpoints link to their predecessors via prev_checkpoint_id
7. **Signed payload binding** - event_seq and event_hash in signed payload match checkpoint
8. **Ed25519 signatures** - Checkpoint signatures verified against public key

## Exit Codes

- 0 = PASS (all checks passed)
- 1 = FAIL or error

## Files

- `verify.js` - Compiled standalone verifier (runs with Node.js 18+, no dependencies)
- `verify.ts` - TypeScript source for audit/reference
- `checkpoint_public.pem` - Ed25519 public key for signature verification
- `README.md` - This file

## Key Source

The included `checkpoint_public.pem` was exported from the signing engine at build time.
If the signing key is rotated, a new verifier release must be built to include the updated key.
